#---------------------------------------
#	Import Libraries
#---------------------------------------
import clr
clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")
import codecs
import datetime
import json
import os
import random
import sqlite3
import sys
import time

#---------------------------------------
#	[Required]	Script Information
#---------------------------------------
ScriptName = "Pick Vault"
Website = "http://www.twitch.tv/Zerro0713"
Description = "Guess the Combination of the Vault"
Creator = "Zerro0713"
Version = "1.1.0.0"

#---------------------------------------
#	Set Variables
#---------------------------------------
DatabaseFile = os.path.join(os.path.dirname(__file__), "PickVaultDatabase.sqlite")
SettingsFile = os.path.join(os.path.dirname(__file__), "VaultConfig.json")

#---------------------------------------
# Classes
#---------------------------------------
class Settings:
	
	# Tries to load settings from file if given else set defaults
	# The 'default' variable names need to match UI_Config
	def __init__(self, SettingsFile = None):
		if SettingsFile and os.path.isfile(SettingsFile):
			with codecs.open(SettingsFile, encoding="utf-8-sig", mode="r") as f:
				self.__dict__ = json.load(f, encoding="utf-8")
		else:

			self.togLive = True
			self.command = "!vault"
			self.cmdCheck = "!vaultcheck"
			self.cmdVersion = "!vaultversion"
			self.cmdAdmin = "!vaultadmin"
			self.permission = "Everyone"
			self.betDefault = 50
			self.betCheck = 25
			self.betStart = 1000
			self.betAdditional = 50
			self.betHigh = 1000
			self.togCooldown = True
			self.togCooldownCaster = False
			self.timerCooldown = 300
			self.respCooldownUser = "{0}, the command is still on cooldown for {1} seconds!"
			self.respEmpty = "{0}, to play the game do: {1} <combination>. Combination must be a numeric value from 1 to {2}. You can also check the Low-High values with {3}."
			self.respEmptyCheck = "{0}, to check LOW-HIGH values, do {1} execute. It costs {2} {3} to use this command."
			self.respNotLive = "Sorry {0}, but the stream must be live in order to use that command."
			self.respNotEnoughPoints = "{0}, sorry but you need {1} {2} to use that command."
			self.respGuessInvalid = "{0}, sorry but {1} does not fit the vault criteria. Please try a number from 1 to {2}."
			self.respGuessWin = "Congratulations {0}! {1} was the correct combination to open the vault. Inside you find {2} {3} which includes your {4} {3} guess fees."
			self.respGuessLose = "{0}, sorry but {1} was not the correct combination to open the vault. The vault has increased to {2} {3}. After careful consideration, you conclude that the combination must be... {4}"
			self.respCheck = "{0} spends {1} {2} to reveal that the combination is from {3} to {4}. The vault now has {5} {2} in it."
			
	# Reload settings on save through UI
	def ReloadSettings(self, data):
		self.__dict__ = json.loads(data, encoding="utf-8")
		return

	# Save settings to files (json and js)
	def SaveSettings(self, settingsFile):
		with codecs.open(SettingsFile, encoding="utf-8-sig", mode="w+") as f:
			json.dump(self.__dict__, f, encoding="utf-8")
		with codecs.open(SettingsFile.replace("json", "js"), encoding="utf-8-sig", mode="w+") as f:
			f.write("var settings = {0};".format(json.dumps(self.__dict__, encoding='utf-8')))
		return
		
class InstancedDatabase(object):
	""" Instanced database handler class. """
	def __init__(self, databasefile):
		self._connection = sqlite3.connect(databasefile, check_same_thread=False)
		self._cursor = self._connection.cursor()

	def execute(self, sqlquery, queryargs=None):
		""" Execute a sql query on the instanced database. """
		if queryargs:
			self._cursor.execute(sqlquery, queryargs)
		else:
			self._cursor.execute(sqlquery)
		return self._cursor

	def commit(self):
		""" Commit any changes of the instanced database. """
		self._connection.commit()

	def close(self):
		""" Close the instanced database connection. """
		self._connection.close()
		return

	def __del__(self):
		""" Close the instanced database connection on destroy. """
		self._connection.close()
		
#---------------------------------------
#	[Required] Intialize Data (Only called on Load)
#---------------------------------------
def Init():

	global CursorDb, MySettings

	MySettings = Settings(SettingsFile)
	CursorDb = InstancedDatabase(DatabaseFile)
	
	# Create db file if not exists
	
	CursorDb.execute("CREATE TABLE IF NOT EXISTS `Statistics` ("
										"`Id` INTEGER PRIMARY KEY,"
										"`Unix` INTEGER,"
										"`CreateDate` TEXT,"
										"`UpdateDate` TEXT,"
										"`Username` TEXT UNIQUE," 
										"`WinAmt` INTEGER,"
										"`LoseAmt` INTEGER,"
										"`WinMatch` INTEGER,"
										"`LoseMatch` INTEGER,"
										"`DrawMatch` INTEGER," 
										"`WinHigh` INTEGER,"
										"`LoseHigh` INTEGER)"
										)
	CursorDb.execute("CREATE TABLE IF NOT EXISTS `VaultInfo` ("
										"`Id` INTEGER PRIMARY KEY,"
										"`Unix` INTEGER,"
										"`CreateDate` TEXT,"
										"`UpdateDate` TEXT,"
										"`Username` TEXT UNIQUE," 
										"`Combination` INTEGER,"
										"`Jackpot` INTEGER,"
										"`Low` INTEGER,"
										"`High` INTEGER)"
										)
	CursorDb.execute("CREATE TABLE IF NOT EXISTS `Version` ("
										"`Unix` INTEGER,"
										"`CreateDate` TEXT,"
										"`UpdateDate` TEXT,"
										"`VerNum` INTEGER)"
										)
	CursorDb.commit()
	
	return
	
#---------------------------------------
#	Script is going to be unloaded
#---------------------------------------
def Unload():
	CursorDb.close()
	MySettings.SaveSettings(SettingsFile)
	return

#---------------------------------------
#	Script is enabled or disabled on UI
#---------------------------------------
def ScriptToggled(state):
	if not state:
		MySettings.SaveSettings(SettingsFile)
	return

#---------------------------------------
#	[Required] Execute Data / Process Messages
#---------------------------------------
def Execute(data):

	# Checks to see if the command is coming from a chat message.
	if data.IsChatMessage():

		unix = time.time()
		date = str(datetime.datetime.fromtimestamp(unix).strftime('%Y-%m-%d %H:%M:%S'))
		user = data.User
		userPoints = Parent.GetPoints(user)
		timer = ""
		verNum = 1
		sqlRow = CursorDb.execute("SELECT * FROM `Version` WHERE `VerNum` = ?", (verNum,)).fetchone()
		# No row result: Version doesn't exist
		if sqlRow is None:
			dbVersion = 1
			newEntry = (unix, date, date, dbVersion)
			CursorDb.execute("INSERT INTO `Version` VALUES (?,?,?,?)", newEntry)
			Parent.Log(ScriptName, "Database v{0} Created: {1}".format(dbVersion, date))
			CursorDb.commit()
		
		# Checks to see if THIEF is in the database
		vaultName = "vault"
		sqlRow = CursorDb.execute("SELECT * FROM `VaultInfo` WHERE `Username` = ?", (vaultName,)).fetchone()
		# No row result: Creates Thief
		if sqlRow is None:
			vaultCombo = Parent.GetRandom(1, MySettings.betHigh)
			vaultHigh = MySettings.betHigh + 1
			newEntry = (unix, date, date, vaultName, vaultCombo, MySettings.betStart, 0, vaultHigh)
			CursorDb.execute("INSERT INTO `VaultInfo`(`Unix`, `CreateDate`, `UpdateDate`, `Username`, `Combination`, `Jackpot`, `Low`, `High`) VALUES (?,?,?,?,?,?,?,?)", newEntry)
			Parent.Log(ScriptName, "Vault: {0} Created: {1}".format(vaultCombo, date))
			CursorDb.commit()

		sqlRow = CursorDb.execute("SELECT * FROM `VaultInfo` WHERE `Username` = ?", (vaultName,)).fetchone()
		vaultCombo = sqlRow[5]
		# Checks to see if betHigh changed and vaultCombo is greater than new betHigh
		if vaultCombo > MySettings.betHigh :
			vaultComboNew = Parent.GetRandom(1, MySettings.betHigh)
			vaultHigh = MySettings.betHigh + 1
			updateEntry = (date, vaultComboNew, 0, vaultHigh, vaultName)
			CursorDb.execute("UPDATE `VaultInfo` SET `UpdateDate` = ?, `Combination` = ?, `Low` = ?, `High` = ? WHERE `Username` = ?", updateEntry)
			CursorDb.commit()
		
		# VAULT COMMAND
		if data.GetParam(0).lower() == MySettings.command and Parent.HasPermission(user, MySettings.permission, ""):
			
			# Checks to see if the stream needs to be LIVE and IS LIVE 
			if not MySettings.togLive or Parent.IsLive():
				
				# Checks to see if USER entered just the COMMAND
				if data.GetParamCount() == 1 :
					Parent.SendTwitchMessage(MySettings.respEmpty.format(user, MySettings.command, MySettings.betHigh, MySettings.cmdCheck))
				else:
					
					timerCooldownUser = Parent.GetUserCooldownDuration(ScriptName, MySettings.command, user)
					
					# Checks to see if USER is on COOLDOWN
					if MySettings.togCooldown and Parent.IsOnUserCooldown(ScriptName, MySettings.command, user):
						# Checks to see if USER is the CASTER and CASTER COOLDOWN is ENABLED
						if not Parent.HasPermission(user, "Caster", "") :
							Parent.SendTwitchMessage(MySettings.respCooldownUser.format(user, timerCooldownUser))
						elif MySettings.togCooldownCaster and Parent.HasPermission(user, "Caster", "") :
							Parent.SendTwitchMessage(MySettings.respCooldownUser.format(user, timerCooldownUser))
					else: 
					
						# Checks to see if USER has enough CURRENCY
						if userPoints < MySettings.betDefault :
							Parent.SendTwitchMessage(MySettings.respNotEnoughPoints.format(user, MySettings.betDefault, Parent.GetCurrencyName()))
						else:
						
							try:
								vaultGuess = int(data.GetParam(1))
							except:
								vaultGuess = 0
								
							# Checks to see if the GUESS was VALID
							if vaultGuess < 1 or vaultGuess > MySettings.betHigh :
								Parent.SendTwitchMessage(MySettings.respGuessInvalid.format(user, data.GetParam(1), MySettings.betHigh))
							else:
								sqlRow = CursorDb.execute("SELECT * FROM `VaultInfo` WHERE `Username` = ?", (vaultName,)).fetchone()
								vaultCombo = sqlRow[5]
								vaultAmount = sqlRow[6] + MySettings.betDefault
								Parent.RemovePoints(user, MySettings.betDefault)
								
								# USER WINS
								if vaultGuess == vaultCombo :
									vaultComboNew = Parent.GetRandom(1, MySettings.betHigh)
									updateEntry = (date, vaultComboNew, MySettings.betStart, 0, MySettings.betHigh + 1, vaultName)
									CursorDb.execute("UPDATE `VaultInfo` SET `UpdateDate` = ?, `Combination` = ?, `Jackpot` = ?, `Low` = ?, `High` = ? WHERE `Username` = ?", updateEntry)
									CursorDb.commit()
									Parent.AddPoints(user, vaultAmount)
									Parent.SendTwitchMessage(MySettings.respGuessWin.format(user, vaultCombo, vaultAmount, Parent.GetCurrencyName(), MySettings.betDefault))
								# USER LOSES
								else:
									
									if vaultGuess < vaultCombo :
										vaultHint = "HIGHER"
										vaultLow = max(sqlRow[7], vaultGuess)
										vaultHigh = sqlRow[8]
									if vaultGuess > vaultCombo :
										vaultHint = "LOWER"
										vaultLow = sqlRow[7]
										vaultHigh = min(sqlRow[8], vaultGuess)
									
									vaultAmountNew = vaultAmount + MySettings.betAdditional
									
									updateEntry = (date, vaultAmountNew, vaultLow, vaultHigh, vaultName)
									CursorDb.execute("UPDATE `VaultInfo` SET `UpdateDate` = ?, `Jackpot` = ?, `Low` = ?, `High` = ? WHERE `Username` = ?", updateEntry)
									CursorDb.commit()
									Parent.SendTwitchMessage(MySettings.respGuessLose.format(user, vaultGuess, vaultAmountNew, Parent.GetCurrencyName(), vaultHint))
					
								Parent.AddUserCooldown(ScriptName, MySettings.command, user, MySettings.timerCooldown)
			
			# Stream is NOT LIVE Response
			else:
				Parent.SendTwitchMessage(MySettings.respNotLive.format(user))
				
		# CHECK COMMAND
		if data.GetParam(0).lower() == MySettings.cmdCheck and Parent.HasPermission(user, MySettings.permission, ""):
			
			# Checks to see if USER entered just the COMMAND
			if data.GetParamCount() == 1 or data.GetParam(1).lower() != "execute":
				Parent.SendTwitchMessage(MySettings.respEmptyCheck.format(user, MySettings.cmdCheck, MySettings.betCheck, Parent.GetCurrencyName()))
			else:
			
				# Checks to see if USER has enough CURRENCY
				if userPoints < MySettings.betCheck :
					Parent.SendTwitchMessage(MySettings.respNotEnoughPoints.format(user, MySettings.betCheck, Parent.GetCurrencyName()))
				else:
					
					sqlRow = CursorDb.execute("SELECT * FROM `VaultInfo` WHERE `Username` = ?", (vaultName,)).fetchone()
					vaultLow = sqlRow[7] + 1
					vaultMax = sqlRow[8] - 1
					vaultAmount = sqlRow[6] + MySettings.betCheck
					Parent.SendTwitchMessage(MySettings.respCheck.format(user, MySettings.betCheck, Parent.GetCurrencyName(), vaultLow, vaultMax, vaultAmount))
					updateEntry = (date, vaultAmount, vaultName)
					CursorDb.execute("UPDATE `VaultInfo` SET `UpdateDate` = ?, `Jackpot` = ? WHERE `Username` = ?", updateEntry)
					CursorDb.commit()
					Parent.RemovePoints(user, MySettings.betCheck)

		# ADMIN COMMANDS
		elif data.GetParam(0).lower() == MySettings.cmdAdmin and (Parent.HasPermission(user, "Caster", "") or user == "zerro0713"):
			
			# Checks to see if USER entered just the COMMAND
			if data.GetParamCount() == 1 or (data.GetParam(1).lower() != "add" and data.GetParam(1).lower() != "amount" and data.GetParam(1).lower() != "answer" and data.GetParam(1).lower() != "reroll"):
				Parent.SendTwitchWhisper(user, "Syntax: {0} [add|amount|answer|reroll] <value>".format(MySettings.cmdAdmin))
			else:
				
				adminAction = data.GetParam(1).lower()
				sqlRow = CursorDb.execute("SELECT * FROM `VaultInfo` WHERE `Username` = ?", (vaultName,)).fetchone()
				vaultCombo = sqlRow[5]
				vaultAmount = sqlRow[6]
				
				# ADD CURRENCY
				if adminAction == "add" :
					try:
						adminAmount = int(data.GetParam(2))
					except:
						adminAmount = 0
						
					# Checks to see if a NUMERIC VALUE was inputted
					if adminAmount == 0:
						Parent.SendTwitchWhisper(user, "Add Vault Amount must be a numeric value greater than or less than 0")
					else:
						vaultAmountNew = vaultAmount + adminAmount
						updateEntry = (date, vaultAmountNew, vaultName)
						CursorDb.execute("UPDATE `VaultInfo` SET `UpdateDate` = ?, `Jackpot` = ? WHERE `Username` = ?", updateEntry)
						CursorDb.commit()
						Parent.SendTwitchMessage("[VAULTADMIN] Vault Jackpot Amount has been adjusted by {0} {1}. Jackpot is now {2} {1}.".format(adminAmount, Parent.GetCurrencyName(), vaultAmountNew))
				
				# ANSWER CHECK
				elif adminAction == "amount" :
					Parent.SendTwitchMessage("[VAULTADMIN] Vault Jackpot Amount is currently {0} {1}.".format(vaultAmount, Parent.GetCurrencyName()))
					
				# ANSWER CHECK
				elif adminAction == "answer" :
					Parent.SendTwitchWhisper(user, "[VAULTADMIN] Vault combination is {0}.".format(vaultCombo))
					
				# REROLL COMBINATION
				elif adminAction == "reroll" :
					vaultComboNew = Parent.GetRandom(1, MySettings.betHigh)
					updateEntry = (date, vaultComboNew, vaultName)
					CursorDb.execute("UPDATE `VaultInfo` SET `UpdateDate` = ?, `Combination` = ? WHERE `Username` = ?", updateEntry)
					CursorDb.commit()
					Parent.SendTwitchMessage("[VAULTADMIN] Vault combination has been resetted.")
				
				CursorDb.commit()
		# SCRIPT VERSION
		elif data.GetParam(0).lower() == MySettings.cmdVersion and (Parent.HasPermission(user, "Caster", "") or user == "zerro0713"):
			Parent.SendTwitchMessage("{0} v{1} Created By: {2} at {3}".format(ScriptName, Version, Creator, Website))
	
	return
	
#---------------------------------------
# Reload Settings on Save
#---------------------------------------
def ReloadSettings(jdata):
	MySettings.ReloadSettings(jdata)
	Init()
	return

#---------------------------------------
#	[Required] Tick Function
#---------------------------------------
def Tick():
	return
